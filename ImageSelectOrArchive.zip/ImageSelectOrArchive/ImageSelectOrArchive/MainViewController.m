//
//  ViewController.m
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/10.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "MainViewController.h"
#import "LMDraftBoxViewController.h"
#import "LMSelectImageViewController.h"

@interface MainViewController ()
/* 选择图片 */
@property(nonatomic,strong)UIButton *selectBtn;
/* 草稿箱 */
@property(nonatomic,strong)UIButton *draftBoxBtn;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //基础创建
    [self baseSetting];
}
-(void)baseSetting
{
    self.title = @"图片多选和本地存储";
    
    UIButton *button1 = [[UIButton alloc]initWithFrame:CGRectMake(0, 120, kScreenW, 48)];
    [button1 setTitle:@"选择图片" forState:UIControlStateNormal];
    [button1 setBackgroundColor:[UIColor colorWithRed:0.6 green:0.5 blue:0.4 alpha:1.0]];
    button1.titleLabel.textColor = [UIColor whiteColor];
    [button1 addTarget:self action:@selector(selectBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    self.selectBtn = button1;
    
    UIButton *button2 = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(button1.frame)+5, kScreenW, 48)];
    [button2 setTitle:@"草稿箱" forState:UIControlStateNormal];
    [button2 setBackgroundColor:[UIColor colorWithRed:0.6 green:0.5 blue:0.4 alpha:1.0]];
    button2.titleLabel.textColor = [UIColor whiteColor];
    [button2 addTarget:self action:@selector(draftBoxBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    self.draftBoxBtn = button2;
}
-(void)selectBtnClick
{
    LMSelectImageViewController *selectImageVC = [[LMSelectImageViewController alloc]init];
    [self.navigationController pushViewController:selectImageVC animated:YES];
}
-(void)draftBoxBtnClick
{
    LMDraftBoxViewController *draftBoxVC = [[LMDraftBoxViewController alloc]init];
    [self.navigationController pushViewController:draftBoxVC animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
