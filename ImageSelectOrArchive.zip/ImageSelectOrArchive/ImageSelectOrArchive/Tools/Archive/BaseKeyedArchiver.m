//
//  BaseKeyedArchiver.m
//  DataWriteToFile
//
//  Created by limin on 16/7/18.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "BaseKeyedArchiver.h"
/**
 *  文件后缀名
 */
NSString *const kFileDefaultPathExtension = @"cache";
/**
 *  默认文件名
 */
NSString *kFileDefaultFileName = @"defaultFile";
@interface BaseKeyedArchiver ()

@end
@implementation BaseKeyedArchiver

/**
 *  单例
 *
 *  @return 返回单例对象
 */
+ (instancetype)sharedClient
{
    static BaseKeyedArchiver *client = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        client = [[BaseKeyedArchiver alloc]init];
    });
//    kFileDefaultFileName = [[NSUserDefaults standardUserDefaults]valueForKey:isLoginStatus]?[[NSUserDefaults standardUserDefaults]valueForKey:PHONE]:@"defaultFile";
    return client;
}

/**
 *  对数据进行归档
 *
 *  @param dataArray 需要进行归档的数据
 */
-(void)setArchiverDataWithData:(NSMutableArray *)dataArray
{
    NSString *fileAllPath = [self getAllFilePath];
    if([[NSFileManager defaultManager] fileExistsAtPath:fileAllPath]) {//先将该地址存在的文件删除，再存储。
        NSError *error    = nil;
        if(![[NSFileManager defaultManager] removeItemAtPath:fileAllPath error:&error]) {
            NSLog(@"Cannot remove file: %@", error);
        }
    }
    [NSKeyedArchiver archiveRootObject:dataArray toFile:fileAllPath];
}

/**
 *  获取解归档的数据
 *
 *  @return 解归档后的数组
 */
-(NSMutableArray*)getArchiverData
{
    NSString *fileAllPath = [self getAllFilePath];
    NSMutableArray *newDataArray = [NSKeyedUnarchiver unarchiveObjectWithFile:fileAllPath];
    return newDataArray;
}


/**
 *  获取文件路径
 *
 *  @return 返回文件路径
 */
-(NSString *)getAllFilePath
{
    NSString *paths = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *fileAllPath = [[paths stringByAppendingPathComponent:kFileDefaultFileName] stringByAppendingPathExtension:kFileDefaultPathExtension];
    return fileAllPath;
}

@end
