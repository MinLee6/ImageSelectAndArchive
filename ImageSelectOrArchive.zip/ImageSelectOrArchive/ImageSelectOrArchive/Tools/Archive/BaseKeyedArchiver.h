//
//  BaseKeyedArchiver.h
//  DataWriteToFile
//
//  Created by limin on 16/7/18.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseKeyedArchiver : NSObject
/**
 *  单例
 *
 *  @return 返回单例对象
 */
+ (instancetype)sharedClient;

/**
 *  对数据进行归档
 *
 *  @param dataArray 需要进行归档的数据
 */
-(void)setArchiverDataWithData:(NSMutableArray *)dataArray;

/**
 *  获取解归档的数据
 *
 *  @return 解归档后的数组
 */
-(NSMutableArray*)getArchiverData;

/**
 *  获取文件路径
 *
 *  @return 返回文件路径
 */
-(NSString *)getAllFilePath;
@end
