//
//  LMSelectImageViewController.h
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/10.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMDraftModel;
@interface LMSelectImageViewController : UIViewController
/*
 *从草稿箱进入该页面时已经携带了参数（标题，内容，图片，时间等），
 此时需要将该数据提取出来，赋值给该控制器，然后对相应的view赋值。
 */
/* 图片 */
@property(nonatomic,strong)NSMutableArray *selectedPhotos;
/* 图片资源 */
@property(nonatomic,strong)NSMutableArray *selectedAssets;
@property(nonatomic,assign)BOOL isSelectOriginalPhoto;
/* 标题 */
@property(nonatomic,copy)NSString *titleStr;
/* 是否来自草稿箱 */
@property(nonatomic,assign)BOOL isFromDraftBox;
/* 从草稿箱进来的点击的第几个 */
@property(nonatomic,assign)NSUInteger draftIndex;
/* model */
@property(nonatomic,strong)LMDraftModel *draftModel;
@end
