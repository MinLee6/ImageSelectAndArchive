//
//  LMDraftBoxViewController.m
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/10.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "LMDraftBoxViewController.h"
#import "DraftBoxTableViewCell.h"
#import "LMSelectImageViewController.h"
#import "LMDraftModel.h"
#import "BaseKeyedArchiver.h"
#import <Photos/Photos.h>
@interface LMDraftBoxViewController ()<UITableViewDelegate,UITableViewDataSource>
/* 表格 */
@property(nonatomic,strong)UITableView *draftTableView;
/* 数组 */
@property(nonatomic,strong)NSMutableArray *draftArrays;

@end
static NSString *cellID = @"DraftBoxCellID";
@implementation LMDraftBoxViewController
#pragma mark - 懒加载
-(NSMutableArray *)draftArrays
{
    if (!_draftArrays) {
        _draftArrays = [NSMutableArray array];
    }
    return _draftArrays;
}
#pragma mark - View 配置
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //获取归档的数据
    [self getUnArchiveData];
}
-(void)getUnArchiveData
{
    //清除原来的数据
    [self.draftArrays removeAllObjects];
    //解析文件数据
    NSArray *array = [[BaseKeyedArchiver sharedClient]getArchiverData];
    [self.draftArrays addObjectsFromArray:array];
    [self.draftTableView reloadData];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupView];
}
-(void)setupView
{
    self.title = @"草稿箱";
    self.view.backgroundColor = [UIColor whiteColor];
    //创建表格
    self.draftTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScreenH) style:UITableViewStylePlain];
    self.draftTableView.backgroundColor = [UIColor yellowColor];
    self.draftTableView.rowHeight = 54;
    self.draftTableView.delegate = self;
    self.draftTableView.dataSource = self;
    [self.draftTableView registerNib:[UINib nibWithNibName:@"DraftBoxTableViewCell" bundle:nil] forCellReuseIdentifier:cellID];
    [self.view addSubview:self.draftTableView];
}
#pragma mark - <UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.draftArrays.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //
    DraftBoxTableViewCell *cell = (DraftBoxTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        //
        NSLog(@"none");
    }
    cell.draftModel = self.draftArrays[indexPath.row];
    return cell;
}
#pragma mark - <UITableViewDelegate>
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    LMSelectImageViewController *selectVC = [[LMSelectImageViewController alloc]init];
    selectVC.isFromDraftBox = YES;//来自草稿箱
    selectVC.draftIndex = indexPath.row;//第几行被点击
    //点击行的数据
    LMDraftModel *model = self.draftArrays[indexPath.row];
    selectVC.draftModel = model;
    selectVC.titleStr = model.articleTitle;
    selectVC.isSelectOriginalPhoto = model.OriginalPhoto;//是否是原图
    //判断当前图片是否已经被删除，（删除－显示的时候无这张图）
    NSMutableArray *photosArray = [NSMutableArray array];
    NSMutableArray *assetsArray = [NSMutableArray array];
    for (NSInteger i=0; i<model.assetArrays.count; i++) {
        NSString *archiveLocalId = model.assetArrays[i];
        //获取所有资源的集合，并按照资源的创建时间排序
        PHFetchOptions *options = [[PHFetchOptions alloc]init];
        PHFetchResult *assetsFetchResults = [PHAsset fetchAssetsWithOptions:options];
        //只有在图片资源中找到对应的信息，该图片才在手机中存在
        [assetsFetchResults enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            PHAsset *asset = obj;
            if ([archiveLocalId isEqualToString:asset.localIdentifier]) {
                //剩余的图片
                [photosArray addObject:model.pictureArrays[i]];
                [assetsArray addObject:asset];
            }
        }];
    }
    selectVC.selectedPhotos = photosArray;
    selectVC.selectedAssets = assetsArray;
    
    [self.navigationController pushViewController:selectVC animated:YES];
}
#pragma mark - 哪几行可以编辑
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
#pragma mark - UITableViewDelegate编辑事件
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return @"删除";
}
//继承该方法时,左右滑动会出现删除按钮(自定义按钮),点击按钮时的操作
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self deleteDraftAtIndex:indexPath];
}
-(void)deleteDraftAtIndex:(NSIndexPath *)indexPath
{
    //先删除数据
    [self.draftArrays  removeObjectAtIndex:indexPath.row];
    [self.draftTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
    
    //归档
    [[BaseKeyedArchiver sharedClient]setArchiverDataWithData:self.draftArrays];
    
    [self.draftTableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
