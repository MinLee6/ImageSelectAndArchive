//
//  LMSelectImageViewController.m
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/10.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "LMSelectImageViewController.h"

//图片选择
#import "TZImagePickerController.h"
#import "UIView+Layout.h"
#import "TZTestCell.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/Photos.h>
#import "LxGridViewFlowLayout.h"
#import "TZImageManager.h"
#import "TZVideoPlayerController.h"

#import "LMDraftModel.h"
#import "BaseKeyedArchiver.h"
#import "LMPHAssetModel.h"

@interface LMSelectImageViewController ()<TZImagePickerControllerDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    CGFloat _itemWH;//图片的宽高
    LxGridViewFlowLayout *_layout;//布局样式
    CGFloat _margin;//距离屏幕两边的间距
}
/* 标题 */
@property(nonatomic,strong)UITextField *titleTextField;
/* 图片选择 */
@property(nonatomic,strong)UIImagePickerController *imagePickerVC;
/* 图片容器 */
@property(nonatomic,strong)UICollectionView *collectionView;
@end
static NSString *cellID = @"TZTestCell";
@implementation LMSelectImageViewController
#pragma mark - 懒加载
-(NSMutableArray *)selectedAssets
{
    if (!_selectedAssets) {
        _selectedAssets = [NSMutableArray array];
    }
    return _selectedAssets;
}
-(NSMutableArray *)selectedPhotos
{
    if (!_selectedPhotos) {
        _selectedPhotos = [NSMutableArray array];
    }
    return _selectedPhotos;
}
-(UIImagePickerController *)imagePickerVC
{
    if (!_imagePickerVC) {
        _imagePickerVC = [[UIImagePickerController alloc]init];
        _imagePickerVC.delegate = self;
        //改变相册选择页的导航栏外观
        _imagePickerVC.navigationBar.barTintColor = self.navigationController.navigationBar.barTintColor;
        _imagePickerVC.navigationBar.tintColor = self.navigationController.navigationBar.tintColor;
        UIBarButtonItem *lmBarItem, *BarItem;
        if (iOS9Later) {
            lmBarItem = [UIBarButtonItem appearanceWhenContainedInInstancesOfClasses:@[[TZImagePickerController class]]];
            BarItem = [UIBarButtonItem appearanceWhenContainedInInstancesOfClasses:@[[UIImagePickerController class]]];
        }else
        {
            lmBarItem = [UIBarButtonItem appearanceWhenContainedIn:[TZImagePickerController class], nil];
            BarItem = [UIBarButtonItem appearanceWhenContainedIn:[UIImagePickerController class], nil];
        }
        NSDictionary *titleTextAttributes = [lmBarItem titleTextAttributesForState:UIControlStateNormal];
        [BarItem setTitleTextAttributes:titleTextAttributes forState:UIControlStateNormal];
    }
    return _imagePickerVC;
}
#pragma mark - View配置
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupBaseView];
}
-(void)setupBaseView
{
    self.title = @"编辑页";
    self.view.backgroundColor = [UIColor whiteColor];
    //导航
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"😸返回" style:UIBarButtonItemStylePlain target:self action:@selector(leftBackItemClick)];
    //标题
    UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(kCellMargin, KNavH+kCellMargin, kScreenW-kCellMargin*2, 44)];
    textField.tintColor = [UIColor blueColor];
    textField.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    textField.placeholder = @"请输入标题";
    [self.view addSubview:textField];
    self.titleTextField = textField;
    if (self.titleStr.length>0) {
        self.titleTextField.text = self.titleStr;
    }
    
    //图片
    //布局样式
    _layout = [[LxGridViewFlowLayout alloc]init];
    _margin = 15;
    _itemWH = (self.view.tz_width - 2*_margin-4)/3-_margin;
    _layout.itemSize = CGSizeMake(_itemWH, _itemWH);
    _layout.minimumLineSpacing = _margin;//行间距
    _layout.minimumInteritemSpacing = _margin;//项间距
    //重新计算item的个数
    _layout.itemCount = self.selectedPhotos.count;
    //创建collectionview
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(textField.frame)+_margin, self.view.tz_width, _margin+_itemWH) collectionViewLayout:_layout];
    _collectionView.alwaysBounceVertical = NO;
    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.scrollEnabled = NO;
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.contentInset = UIEdgeInsetsMake(_margin, _margin, _margin, _margin);
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    [self setupContentSize];
    [self.view addSubview:_collectionView];
    [_collectionView registerClass:[TZTestCell class] forCellWithReuseIdentifier:cellID];
    
}
#pragma mark - 返回事件
-(void)leftBackItemClick
{
    [self.view endEditing:YES];
    //判断是来自草稿箱中点击进入的该界面
    if (self.isFromDraftBox) {//来自草稿箱
        if ([self justOldNewChange]) {//判断内容是否有变化
            [self leftBackAction];
        }else
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }else
    {
        [self leftBackAction];
    }
}
-(void)leftBackAction
{
    //保存发送的内容：
    NSString *text = self.titleTextField.text;
    //图片选择
    if (text.length != 0 || self.selectedAssets.count != 0) {
        
        UIAlertController *backSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        [backSheet addAction:[UIAlertAction actionWithTitle:@"保存草稿箱" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self saveDraftBox];
            [self.navigationController popViewControllerAnimated:YES];
        }]];
        [backSheet addAction:[UIAlertAction actionWithTitle:@"不保存" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            [self.navigationController popViewControllerAnimated:YES];
        }]];
        [backSheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }]];
        [self presentViewController:backSheet animated:YES completion:nil];
        
    }else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
#pragma mark - 判断是否改变
-(BOOL)justOldNewChange
{
    BOOL isChange = NO;
    if (![self.titleTextField.text isEqualToString:self.draftModel.articleTitle]) {//两个相同
        isChange = YES;
    }
    if (self.draftModel.pictureArrays.count != self.selectedPhotos.count) {//图片前后个数不等
        isChange = YES;
    }else
    {
        NSUInteger count = self.draftModel.pictureArrays.count;
        for (int i=0; i<count; i++) {
            //取出image对比
            UIImage *img1 = self.draftModel.pictureArrays[i];
            UIImage *img2 = self.selectedPhotos[i];
            NSData *data1 = UIImagePNGRepresentation(img1);
            NSData *data2 = UIImagePNGRepresentation(img2);
            if (![data2 isEqual:data1]) {
                isChange = YES;
                break;
            }
        }
    }
    
    return isChange;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
#pragma mark - 保存到草稿箱
-(void)saveDraftBox
{
    //时间
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *destDateString = [dateFormatter stringFromDate:[NSDate date]];
    //model
    LMDraftModel *model = [[LMDraftModel alloc]init];
    model.time = destDateString;
    model.articleTitle = self.titleTextField.text;
    model.pictureArrays = self.selectedPhotos;
    //图片
    NSMutableArray *assetArray = [NSMutableArray array];
    for (NSInteger i=0; i<_selectedAssets.count; i++) {
        if ([_selectedAssets[i] isKindOfClass:[PHAsset class]]) {
            PHAsset *ass = _selectedAssets[i];
            //获取所有的资源集合，并按资源的创建时间排序
            PHFetchOptions *options = [[PHFetchOptions alloc]init];
            PHFetchResult *assetsFetchResult = [PHAsset fetchAssetsWithOptions:options];
            [assetsFetchResult enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                PHAsset *ass2 = obj;
                if ([ass.localIdentifier isEqualToString:ass2.localIdentifier]) {
                    [assetArray addObject:ass.localIdentifier];
                }
            }];
        }else if ([_selectedAssets[i] isKindOfClass:[ALAsset class]])
        {
            NSLog(@"ALAsset");
        }
    }
    model.assetArrays = assetArray;
    model.OriginalPhoto = _isSelectOriginalPhoto;
    //归档数据{A:先取出存储的数据，B:判断数据是否已存在，（1，第一次进去，直接插入数据。2:从草稿箱进去的，直接替换对应的数据）}
    NSMutableArray *draftArrays = [[BaseKeyedArchiver sharedClient]getArchiverData];
    if (!draftArrays) {
        draftArrays = [NSMutableArray array];
    }
    if (self.isFromDraftBox) {
        [draftArrays replaceObjectAtIndex:self.draftIndex withObject:model];
    }else
    {
        [draftArrays insertObject:model atIndex:0];
    }
    [[BaseKeyedArchiver sharedClient]setArchiverDataWithData:draftArrays];
    
}
#pragma mark - <UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //图片＋选择
    return self.selectedAssets.count+1;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    TZTestCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    cell.videoImageView.hidden = YES;
    if (indexPath.row == _selectedAssets.count) {
        cell.imageView.image = [UIImage imageNamed:@"AlbumAddBtn"];
        cell.deleteBtn.hidden = YES;
    }else
    {
        cell.imageView.image = _selectedPhotos[indexPath.item];
        cell.asset = _selectedAssets[indexPath.item];
        cell.deleteBtn.hidden = NO;
    }
    cell.deleteBtn.tag = indexPath.item;
    [cell.deleteBtn addTarget:self action:@selector(deleteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
#pragma mark - 删除图片
-(void)deleteBtnClick:(UIButton *)sender
{
    //删除数组中的图片
    [_selectedPhotos removeObjectAtIndex:sender.tag];
    [_selectedAssets removeObjectAtIndex:sender.tag];
    //重新计算item的个数
    _layout.itemCount = _selectedPhotos.count;
    [_collectionView performBatchUpdates:^{
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:sender.tag inSection:0];
        [_collectionView deleteItemsAtIndexPaths:@[indexPath]];
    } completion:^(BOOL finished) {
        [self setupContentSize];
        [_collectionView reloadData];
    }];
}
#pragma mark - <UICollectionViewDelegate>
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == _selectedPhotos.count) {
        [self pushImagePickerController];
        
    } else { // preview photos or video / 预览照片或者视频
        id asset = _selectedAssets[indexPath.row];
        BOOL isVideo = NO;
        if ([asset isKindOfClass:[PHAsset class]]) {
            PHAsset *phAsset = asset;
            isVideo = phAsset.mediaType == PHAssetMediaTypeVideo;
        } else if ([asset isKindOfClass:[ALAsset class]]) {
            ALAsset *alAsset = asset;
            isVideo = [[alAsset valueForProperty:ALAssetPropertyType] isEqualToString:ALAssetTypeVideo];
        }
        if (isVideo) { // perview video / 预览视频
            TZVideoPlayerController *vc = [[TZVideoPlayerController alloc] init];
            TZAssetModel *model = [TZAssetModel modelWithAsset:asset type:TZAssetModelMediaTypeVideo timeLength:@""];
            vc.model = model;
            [self presentViewController:vc animated:YES completion:nil];
        } else { // preview photos / 预览照片
            TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithSelectedAssets:_selectedAssets selectedPhotos:_selectedPhotos index:indexPath.row];
            //允许选择图片原图
            imagePickerVc.allowPickingOriginalPhoto = YES;
            imagePickerVc.isSelectOriginalPhoto = _isSelectOriginalPhoto;
            [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
                _selectedPhotos = [NSMutableArray arrayWithArray:photos];
                _selectedAssets = [NSMutableArray arrayWithArray:assets];
                _isSelectOriginalPhoto = isSelectOriginalPhoto;
                _layout.itemCount = _selectedPhotos.count;
                [self setupContentSize];
                [_collectionView reloadData];
//                _collectionView.contentSize = CGSizeMake(0, ((_selectedPhotos.count + 2) / 3 ) * (_margin + _itemWH));
            }];
            [self presentViewController:imagePickerVc animated:YES completion:nil];
        }
    }
}
- (void)collectionView:(UICollectionView *)collectionView itemAtIndexPath:(NSIndexPath *)sourceIndexPath didMoveToIndexPath:(NSIndexPath *)destinationIndexPath {
    if (sourceIndexPath.item >= _selectedPhotos.count || destinationIndexPath.item >= _selectedPhotos.count) return;
    UIImage *image = _selectedPhotos[sourceIndexPath.item];
    if (image) {
        [_selectedPhotos exchangeObjectAtIndex:sourceIndexPath.item withObjectAtIndex:destinationIndexPath.item];
        [_selectedAssets exchangeObjectAtIndex:sourceIndexPath.item withObjectAtIndex:destinationIndexPath.item];
        [self setupContentSize];
        [_collectionView reloadData];
    }
}

#pragma mark - <TZImagePickerController>
-(void)pushImagePickerController
{
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:kSelectImageMaxCount delegate:self];
    
#pragma mark - 四类个性化设置，这些参数都可以不传，此时会走默认设置
    imagePickerVc.isSelectOriginalPhoto = _isSelectOriginalPhoto;
    
    // 1.如果你需要将拍照按钮放在外面，不要传这个参数
    imagePickerVc.selectedAssets = _selectedAssets; // optional, 可选的
    imagePickerVc.allowTakePicture = YES; // 在内部显示拍照按钮
    
    // 2. Set the appearance
    // 2. 在这里设置imagePickerVc的外观
    // imagePickerVc.navigationBar.barTintColor = [UIColor greenColor];
    // imagePickerVc.oKButtonTitleColorDisabled = [UIColor lightGrayColor];
    // imagePickerVc.oKButtonTitleColorNormal = [UIColor greenColor];
    
    // 3. Set allow picking video & photo & originalPhoto or not
    // 3. 设置是否可以选择视频/图片/原图
    imagePickerVc.allowPickingVideo = NO;//视频
    imagePickerVc.allowPickingImage = YES;//图片
    imagePickerVc.allowPickingOriginalPhoto = YES;//原图
    
    // 4. 照片排列按修改时间升序
    imagePickerVc.sortAscendingByModificationDate = NO;
#pragma mark - 到这里为止
    
    // You can get the photos by block, the same as by delegate.
    // 你可以通过block或者代理，来得到用户选择的照片.
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        
    }];
    
    [self presentViewController:imagePickerVc animated:YES completion:nil];
}
#pragma mark - <TZImagePickerControllerDelegate>
- (void)imagePickerController:(TZImagePickerController *)picker didFinishPickingPhotos:(NSArray *)photos sourceAssets:(NSArray *)assets isSelectOriginalPhoto:(BOOL)isSelectOriginalPhoto {
    _selectedPhotos = [NSMutableArray arrayWithArray:photos];
    _selectedAssets = [NSMutableArray arrayWithArray:assets];
    _isSelectOriginalPhoto = isSelectOriginalPhoto;
    _layout.itemCount = _selectedPhotos.count;
    [self setupContentSize];
    [_collectionView reloadData];
    // _collectionView.contentSize = CGSizeMake(0, ((_selectedPhotos.count + 2) / 3 ) * (_margin + _itemWH));
}
// 如果用户选择了一个视频，下面的handle会被执行
// 如果系统版本大于iOS8，asset是PHAsset类的对象，否则是ALAsset类的对象
- (void)imagePickerController:(TZImagePickerController *)picker didFinishPickingVideo:(UIImage *)coverImage sourceAssets:(id)asset {
    _selectedPhotos = [NSMutableArray arrayWithArray:@[coverImage]];
    _selectedAssets = [NSMutableArray arrayWithArray:@[asset]];
    _layout.itemCount = _selectedPhotos.count;
    // open this code to send video / 打开这段代码发送视频
    // [[TZImageManager manager] getVideoOutputPathWithAsset:asset completion:^(NSString *outputPath) {
    // NSLog(@"视频导出到本地完成,沙盒路径为:%@",outputPath);
    // Export completed, send video here, send by outputPath or NSData
    // 导出完成，在这里写上传代码，通过路径或者通过NSData上传
    
    // }];
    [self setupContentSize];
    [_collectionView reloadData];
    // _collectionView.contentSize = CGSizeMake(0, ((_selectedPhotos.count + 2) / 3 ) * (_margin + _itemWH));
}


#pragma mark - UIImagePickerController
- (void)takePhoto {
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if ((authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied) && iOS8Later) {
        //无权限 做一个友好的提示
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"无法使用相机"message:@"请在iPhone的""设置-隐私-相机""中允许访问相机"preferredStyle:UIAlertControllerStyleAlert];
        [alertController addAction:[UIAlertAction actionWithTitle:@"设置"style:UIAlertActionStyleDestructive handler:^(UIAlertAction*action){
            if (iOS8Later) {// 去设置界面，开启相机访问权限
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
            } else {
                // [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=Privacy&path=Photos"]];
            }
        }]];
        [alertController addAction:[UIAlertAction actionWithTitle:@"取消"style:UIAlertActionStyleCancel handler:^(UIAlertAction*action) {
            NSLog(@"点击了取消按钮");
        }]];
        [self presentViewController:alertController animated:YES completion:nil];
    } else { // 调用相机
        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
        if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
            self.imagePickerVC.sourceType = sourceType;
            if(iOS8Later) {
                _imagePickerVC.modalPresentationStyle = UIModalPresentationOverCurrentContext;
            }
            [self presentViewController:_imagePickerVC animated:YES completion:nil];
        } else {
            NSLog(@"模拟器中无法打开照相机,请在真机中使用");
        }
    }
}
#pragma mark - <TZImagePickerControllerDelegate>
- (void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    if ([type isEqualToString:@"public.image"]) {
        TZImagePickerController *tzImagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:kSelectImageMaxCount delegate:self];
        tzImagePickerVc.sortAscendingByModificationDate = NO;
        [tzImagePickerVc showProgressHUD];
        UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
        // save photo and get asset / 保存图片，获取到asset
        [[TZImageManager manager] savePhotoWithImage:image completion:^{
            [[TZImageManager manager] getCameraRollAlbum:NO allowPickingImage:YES completion:^(TZAlbumModel *model) {
                [[TZImageManager manager] getAssetsFromFetchResult:model.result allowPickingVideo:NO allowPickingImage:YES completion:^(NSArray<TZAssetModel *> *models) {
                    [tzImagePickerVc hideProgressHUD];
                    TZAssetModel *assetModel = [models firstObject];
                    if (tzImagePickerVc.sortAscendingByModificationDate) {
                        assetModel = [models lastObject];
                    }
                    [_selectedAssets addObject:assetModel.asset];
                    [_selectedPhotos addObject:image];
                    [self setupContentSize];
                    [_collectionView reloadData];
                }];
            }];
        }];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - 计算内容的高度
-(void)setupContentSize
{
    //    height = 15 +kTextFieldH + kTextViewH
    //首先计算出来图片的张数％3＊高度＋文字的高度
    NSUInteger row = 1;
    if (_selectedPhotos.count>=1 && _selectedPhotos.count<=2) {
        row = 1;
    }if (_selectedPhotos.count>=3 && _selectedPhotos.count<=5) {
        row = 2;
    }if (_selectedPhotos.count>=6 && _selectedPhotos.count<=9) {
        row = 3;
    }
    CGFloat collectionHeight = row * (_itemWH + _margin);
    self.collectionView.frame =CGRectMake(0, CGRectGetMaxY(self.titleTextField.frame)+_margin, self.view.tz_width, collectionHeight);
    self.collectionView.contentSize = CGSizeMake(0, collectionHeight);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
