//
//  DraftBoxTableViewCell.m
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/13.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "DraftBoxTableViewCell.h"
#import "LMDraftModel.h"
@interface DraftBoxTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *titleStrLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
//约束
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleTrail;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *timeTrail;

@end
@implementation DraftBoxTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
#pragma mark - 赋值
-(void)setDraftModel:(LMDraftModel *)draftModel
{
    _draftModel = draftModel;
    if (draftModel.pictureArrays.count>0) {//有图
        self.titleTrail.constant = 74;
        self.timeTrail.constant = 74;
        self.imgView.hidden = NO;
        self.imgView.image = draftModel.pictureArrays[0];
    }else//无图
    {
        self.titleTrail.constant = 15;
        self.timeTrail.constant = 15;
        self.imgView.hidden = YES;
    }
    self.titleStrLabel.text = draftModel.articleTitle;
    self.timeLabel.text = [NSString stringWithFormat:@"创建时间：%@",draftModel.time];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
