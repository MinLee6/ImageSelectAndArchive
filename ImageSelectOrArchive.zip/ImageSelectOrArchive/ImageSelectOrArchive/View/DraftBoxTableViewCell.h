//
//  DraftBoxTableViewCell.h
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/13.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMDraftModel;
@interface DraftBoxTableViewCell : UITableViewCell
/* 数据 */
@property(nonatomic,strong)LMDraftModel *draftModel;
@end
