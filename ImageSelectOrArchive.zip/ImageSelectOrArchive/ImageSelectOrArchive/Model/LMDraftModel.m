//
//  LMDraftModel.m
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/13.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "LMDraftModel.h"
#import <objc/runtime.h>
@interface LMDraftModel()<NSCoding>
@end
@implementation LMDraftModel
#pragma mark - 归档
-(void)encodeWithCoder:(NSCoder *)aCoder
{
    unsigned int outCount = 0;
    Ivar *ivars = class_copyIvarList([self class], &outCount);
    for (unsigned int i = 0; i<outCount; i++) {
        Ivar ivar = ivars[i];
        NSString *key = [NSString stringWithUTF8String:ivar_getName(ivar)];
        id value = [self valueForKey:key];
        [aCoder encodeObject:value forKey:key];
    }
    free(ivars);
}
#pragma mark - 解归档
-(instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        unsigned int OutCount = 0;
        Ivar *ivars = class_copyIvarList([self class], &OutCount);
        for (unsigned int i=0; i<OutCount; i++) {
            Ivar ivar = ivars[i];
            NSString *key = [NSString stringWithUTF8String:ivar_getName(ivar)];
            [self setValue:[aDecoder decodeObjectForKey:key] forKey:key];
        }
        free(ivars);
    }
    return self;
}
@end
