//
//  LMDraftModel.h
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/13.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMDraftModel : NSObject
/* 文章标题 */
@property(nonatomic,copy)NSString *articleTitle;
/* 时间 */
@property(nonatomic,copy)NSString *time;
/* 图片数组 */
@property(nonatomic,strong)NSArray *pictureArrays;
/** 图片资源*/
@property(nonatomic,strong)NSArray *assetArrays;
/* 图片来源 */
@property(nonatomic,assign)BOOL OriginalPhoto;
@end
