//
//  LMPHAssetModel.m
//  ImageSelectOrArchive
//
//  Created by limin on 16/12/13.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "LMPHAssetModel.h"
@interface LMPHAssetModel()<NSCoding>
@end
@implementation LMPHAssetModel
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self forKey:NSStringFromClass([self class])];
}
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        self = [aDecoder decodeObjectForKey:NSStringFromClass([self class])];
    }
    return self;
}
@end
