//
//  ImageSelectOrArchiveTests.m
//  ImageSelectOrArchiveTests
//
//  Created by limin on 16/12/10.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ImageSelectOrArchiveTests : XCTestCase

@end

@implementation ImageSelectOrArchiveTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
